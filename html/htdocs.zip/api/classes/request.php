<?php
/**
 *  Object responsible for receiving the JSON message from the APP and
 *  parsing it to an object, later to expose that object to the rest of the API
 *
 * @category      Classes
 * @author        Luchev <luchevz@gmail.com>
 * @version       1.0
 * @since         0.1
 * @example
 */

require_once ROOT_FOLDER.'/DBCON/db.php';
require_once ROOT_FOLDER.'/modules/lib.php';

/**
 * TODO
 * @param
 * @return
 */
function GetAllAchievements() {
  // TODO
}


?>
