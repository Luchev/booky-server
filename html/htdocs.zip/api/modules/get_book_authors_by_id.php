<?php
/**
 *
 * @category      Modules
 * @package       DB-Additions
 * @subpackage    Select
 * @uses          DB
 * @author        Luchev <luchevz@gmail.com>
 * @version       1.0
 * @since         0.1
 * @deprecated    0.1
 * @example
 */

require_once ROOT_FOLDER.'/DBCON/db.php';
require_once ROOT_FOLDER.'/modules/lib.php';

/**
 * TODO
 * @param
 * @return
 */
function GetBookAuthorsById($Id) {
  $db = DB::Instance();

  if (!$prep = $db->Prepare('SELECT author_id FROM book_author WHERE book_id = ?')) {
    UpdateError(8); // ERROR-8
  }
  if (!$prep->bind_param('i', $Id)) {
    UpdateError(12); // ERROR-12
  }
  if (!$prep->execute()) {
    UpdateError(15); // ERROR-15
  }
  if (!$res = $prep->get_result()) {
    UpdateError(16); // ERROR-16
  }

  $return = array();
  while ($row = $res->fetch_assoc()) {
    $return[] = $row['author_id'];
  }

  $prep->close();
  return $return;
}


?>
