<?php
/**
 *
 * @category      Modules
 * @package       DB-Additions
 * @subpackage    Select
 * @uses          DB
 * @author        Luchev <luchevz@gmail.com>
 * @version       1.0
 * @since         0.1
 * @deprecated    0.1
 * @example
 */

require_once ROOT_FOLDER.'/DBCON/db.php';
require_once ROOT_FOLDER.'/modules/lib.php';
require_once ROOT_FOLDER.'/modules/get_author_by_id.php';
require_once ROOT_FOLDER.'/modules/get_translation_by_id.php';

/**
 * TODO
 * @param
 * @return
 */
function GetAuthorByIdFull($Id) {
  $return['author'] = GetAuthorById($Id);
  $return['translation']['name'] = GetTranslationById(4, $Id);
  $return['translation']['pen_name'] = GetTranslationById(5, $Id);
  if (isset($return['author']['country_id']) && $return['author']['country_id'] != 0) {
    $return['country'] = GetTranslationById(2, $return['author']['country_id']);
  }

  return $return;
}


?>
