<?php
/**
 *
 * @category      Modules
 * @package       DB-Additions
 * @subpackage    Select
 * @uses          DB
 * @author        Luchev <luchevz@gmail.com>
 * @version       1.0
 * @since         0.1
 * @deprecated    0.1
 * @example
 */

require_once ROOT_FOLDER.'/DBCON/db.php';
require_once ROOT_FOLDER.'/modules/lib.php';
require_once ROOT_FOLDER.'/modules/get_translation_by_id.php';
require_once ROOT_FOLDER.'/modules/get_author_by_id_full.php';
require_once ROOT_FOLDER.'/modules/get_book_by_id.php';
require_once ROOT_FOLDER.'/modules/get_book_authors_by_id.php';
require_once ROOT_FOLDER.'/modules/get_book_tags_by_id.php';

/**
 * TODO
 * @param     int $Id ID by which the book to be looked in the DB
 * @return
 */
function GetBookByIdFull($Id) {
  $return['book'] = GetBookById($Id);
  $authors = GetBookAuthorsById($Id);
  if (isset($authors)) {
    foreach ($authors as $item) {
      $return['authors'][] = GetAuthorByIdFull($item);
    }
  }
  $tags = GetBookTagsById($Id);
  if (isset($tags)) {
    foreach ($tags as $item) {
      $return['tags'][] = GetTranslationById(6, $item);
    }
  }
  if ($return['book']['series_id'] != 0) {
    $return['series'] = GetTranslationById(8, $return['book']['series_id']);
  }
  $return['translation'] = GetTranslationById(7, $return['book']['id']);
  if ($return['book']['language_id'] != 0) {
    $return['language'] = GetTranslationById(3, $return['book']['language_id']);
  }
  if ($return['book']['country_id'] != 0) {
    $return['country'] = GetTranslationById(2, $return['book']['country_id']);
  }

  return $return;
}


?>
