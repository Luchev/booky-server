<?php
/**
 *
 * @category      Modules
 * @package       DB-Additions
 * @subpackage    Select
 * @uses          DB
 * @author        Luchev <luchevz@gmail.com>
 * @version       1.0
 * @since         0.1
 * @deprecated    0.1
 * @example
 */

require_once ROOT_FOLDER.'/modules/get_book_by_id_full.php';

/**
 * TODO
 * @param     int $Id ID by which the book to be looked in the DB
 * @return
 */
function GetBooksByIdFull($Ids) {
  $return = array();
  foreach ($Ids as $item) {
    $return[] = GetBookByIdFull($item);
  }
  return $return;
}


?>
