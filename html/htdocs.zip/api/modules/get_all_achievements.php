<?php
/**
 *
 * @category      Modules
 * @package       DB-Additions
 * @subpackage    Select
 * @author        Luchev <luchevz@gmail.com>
 * @version       1.0
 * @since         0.1
 */

require_once ROOT_FOLDER.'/DBCON/db.php';
require_once ROOT_FOLDER.'/modules/lib.php';

/**
 * @return  
 */
function GetAllAchievements() {
  // TODO
}


?>
