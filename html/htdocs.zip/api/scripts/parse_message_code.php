<?php
/**
 *
 * @category      Scripts
 * @package       DB-Additions
 * @uses          DB
 * @author        Luchev <luchevz@gmail.com>
 * @version       1.0
 * @since         0.1
 * @deprecated    0.1
 * @example
 */

function ParseGetBookByIdFull($messageObj) {
  if (isset($messageObj['ID'])) {
    if (!is_int($messageObj['ID'])) {
      UpdateError(18);
    }
    require_once ROOT_FOLDER.'/modules/get_book_by_id_full.php';
    return GetBookByIdFull($messageObj['ID']);
  } else {
    UpdateError(19);
  }
}

function ParseGetAuthorByIdFull($messageObj) {
  if (isset($messageObj['ID'])) {
    if (!is_int($messageObj['ID'])) {
      UpdateError(18);
    }
    require_once ROOT_FOLDER.'/modules/get_author_by_id_full.php';
    return GetAuthorByIdFull($messageObj['ID']);
  } else {
    UpdateError(19);
  }
}

function ParseGetAllTags($messageObj) {
  require_once ROOT_FOLDER.'/modules/get_all_tags.php';
  return GetAllTags();
}

function ParseGetBooksByIdFull($messageObj) {
  if (isset($messageObj['IDS'])) {
    if (!is_array($messageObj['IDS'])) {
      UpdateError(18);
    }
    require_once ROOT_FOLDER.'/modules/get_books_by_id_full.php';
    return GetBooksByIdFull($messageObj['IDS']);
  } else {
    UpdateError(19);
  }
}


?>
